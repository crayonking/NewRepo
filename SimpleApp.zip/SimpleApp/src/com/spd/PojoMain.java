package com.spd;

public class PojoMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Pojo pojo=new Pojo();
		
		pojo.setId(123);
		pojo.setName("SPD");
		pojo.setRole("Analyst");
		pojo.setMarket("Growth");
		
		System.out.println("Id= "+pojo.getId()+",  Name= "+ pojo.getName()+",  Role= "+pojo.getRole()+",  market= "+pojo.getMarket());
	}

}
